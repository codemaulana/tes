import { Service, CaseStudy, WorkflowStage, FAQItem } from '../types';

export const COMPANY_INFO = {
  name: 'CV. Kafeinarts',
  legalName: 'CV. Kafeinarts Digital Solusindo',
  tagline: 'Brewing Digital Mastery — Software House & Bespoke IT Solutions',
  shortBio: 'Kami adalah studio rekayasa perangkat lunak premium dan konsultan IT arsitektural. Kami merancang web apps, mobile apps, dan sistem enterprise dengan standar zero technical debt dan performa kelas dunia.',
  location: 'Indonesia & Global Remote Engineering',
  email: 'hello@kafeinarts.com',
  whatsappNumber: '6281234567890', // Format standard WA
  establishedYear: '2021',
  metrics: [
    { label: 'Proyek Rilis Sukses', value: '48+', detail: 'Enterprise, SaaS & Startups' },
    { label: 'Client Retention & CSAT', value: '99.4%', detail: 'Tingkat Kepuasan & Retensi' },
    { label: 'Rata-rata Uptime SLA', value: '99.99%', detail: 'High-Availability Architecture' },
    { label: 'Rata-rata Latensi Core', value: '<85ms', detail: 'Edge-Optimized Infrastructure' }
  ]
};

export const SERVICES_DATA: Service[] = [
  {
    id: 'web-engineering',
    number: '01',
    title: 'High-Performance Web Engineering',
    tag: 'SaaS & Enterprise Web',
    shortDesc: 'Pengembangan web app berskala tinggi dengan arsitektur modern, ultra-cepat, dan SEO-optimized.',
    fullDesc: 'Kami membangun platform web skala besar, aplikasi SaaS multi-tenant, dan portal enterprise dengan kecepatan rendering instan, keamanan berlapis, dan responsivitas sempurna di setiap ukuran layar.',
    deliverables: [
      'Single Page Apps & Server-Driven Web Platforms',
      'Micro-Frontend & Multi-Tenant SaaS Architecture',
      'High-throughput REST & GraphQL API Integration',
      'Core Web Vitals Score 95+ (Lighthouse Verified)',
      'Automated End-to-End Testing & CI/CD Pipeline'
    ],
    techStack: ['React', 'Next.js', 'TypeScript', 'Tailwind', 'Node.js', 'PostgreSQL', 'Redis'],
    architectureSummary: 'Edge-rendered frontend with distributed microservices & caching clusters ensuring sub-100ms load times.',
    iconName: 'Globe',
    estimatedTimeline: '6 - 12 Minggu'
  },
  {
    id: 'mobile-development',
    number: '02',
    title: 'Native & Cross-Platform Mobile Apps',
    tag: 'iOS & Android Systems',
    shortDesc: 'Aplikasi mobile native yang mulus, responsif, dan hemat daya dengan standar Human Interface & Material 3.',
    fullDesc: 'Dari aplikasi fintech dengan autentikasi biometrik hingga aplikasi logistik real-time berbasis GPS, kami menghadirkan pengalaman mobile kelas dunia yang stabil dan minim crash rate (<0.01%).',
    deliverables: [
      'Production-Ready iOS & Android Apps',
      'Offline-First Data Sync & Local SQLite/Realm Cache',
      'Hardware Sensor & Biometric Integration',
      'Push Notification & Real-Time WebSocket Streaming',
      'App Store & Google Play Release Management'
    ],
    techStack: ['Flutter', 'React Native', 'Kotlin', 'Swift', 'Firebase', 'Fastlane'],
    architectureSummary: 'Clean Architecture with BLoC/Redux state management and resilient background sync adapters.',
    iconName: 'Smartphone',
    estimatedTimeline: '8 - 14 Minggu'
  },
  {
    id: 'enterprise-erp-crm',
    number: '03',
    title: 'Bespoke Enterprise Systems & ERP',
    tag: 'Custom Business Software',
    shortDesc: 'Digitalisasi alur operasional bisnis kompleks dengan sistem ERP/CRM kustom yang presisi dan aman.',
    fullDesc: 'Hilangkan keterbatasan software generic. Kami merancang sistem ERP, manajemen inventori, supply chain, dan CRM yang disesuaikan persis dengan SOP dan kebutuhan unik industri Anda.',
    deliverables: [
      'Custom ERP, CRM, & Internal Operation Dashboards',
      'Role-Based Access Control (RBAC) & Audit Logging',
      'Seamless Third-Party API & Legacy System Bridge',
      'Automated Financial & Inventory Reporting Engines',
      'Enterprise SLA & On-Premise / Cloud Deployment'
    ],
    techStack: ['Go', 'Python', 'Node.js', 'PostgreSQL', 'Docker', 'Kubernetes'],
    architectureSummary: 'Domain-Driven Design (DDD) with event-driven message queues (RabbitMQ/Kafka) for zero data collision.',
    iconName: 'Layers',
    estimatedTimeline: '10 - 20 Minggu'
  },
  {
    id: 'cloud-devops',
    number: '04',
    title: 'Cloud Infrastructure & DevOps Security',
    tag: 'AWS, GCP & High Availability',
    shortDesc: 'Arsitektur cloud tahan banting, auto-scaling hemat biaya, dan sistem keamanan berlapis berstandar ISO.',
    fullDesc: 'Kami mengonfigurasi dan mengelola infrastruktur cloud Anda agar mampu menangani lonjakan traffic jutaan pengguna tanpa downtime, lengkap dengan monitoring 24/7 dan automated disaster recovery.',
    deliverables: [
      'Infrastructure as Code (Terraform / Pulumi)',
      'Kubernetes Cluster Orchestration & Helm Charts',
      'Automated Zero-Downtime CI/CD Pipelines',
      'DDoS Protection, WAF & OWASP Top 10 Security Audit',
      'Cost Optimization (Penghematan Tagihan Cloud hingga 40%)'
    ],
    techStack: ['AWS', 'Google Cloud', 'Docker', 'Kubernetes', 'Terraform', 'Datadog'],
    architectureSummary: 'Multi-AZ Kubernetes clusters with automated Horizontal Pod Autoscaling and Cloudflare Enterprise Edge.',
    iconName: 'Server',
    estimatedTimeline: '4 - 8 Minggu'
  },
  {
    id: 'ai-api-solutions',
    number: '05',
    title: 'AI Engine & Custom API Automation',
    tag: 'Machine Learning & LLM Integrations',
    shortDesc: 'Integrasi kecerdasan buatan, Retrieval-Augmented Generation (RAG), dan sistem otomasi bisnis cerdas.',
    fullDesc: 'Transformasikan data bisnis Anda menjadi keunggulan kompetitif. Kami membangun asisten AI kustom, sistem klasifikasi dokumen otomatis, dan automasi proses analitik prediktif.',
    deliverables: [
      'Custom LLM Fine-Tuning & Private RAG Pipelines',
      'Vector Database Integration (Pinecone, pgvector)',
      'Automated Document OCR & Natural Language Processing',
      'Enterprise Guardrails & Data Privacy Compliance',
      'High-Concurrency API Gateway & Rate-Limiting'
    ],
    techStack: ['Python', 'FastAPI', 'PyTorch', 'OpenAI', 'LangChain', 'pgvector'],
    architectureSummary: 'Secure private vector embeddings cache connected to streaming async inference pipelines.',
    iconName: 'Cpu',
    estimatedTimeline: '6 - 10 Minggu'
  },
  {
    id: 'ui-ux-systems',
    number: '06',
    title: 'UI/UX Product Design & Systems',
    tag: 'Bespoke Digital Experience',
    shortDesc: 'Desain visual berkelas dunia, riset pengguna mendalam, dan Design System modular yang siap di-scale.',
    fullDesc: 'Setiap pixel dirancang dengan maksud dan tujuan. Kami menciptakan antarmuka yang intuitif, visual memukau anti-AI slop, serta sistem komponen rapi yang mempercepat proses rekayasa kode.',
    deliverables: [
      'Comprehensive Design Systems in Figma & Code Tokens',
      'User Journey Mapping & Information Architecture',
      'Interactive High-Fidelity Prototypes & Usability Tests',
      'Micro-Animations & Visual Design Guidelines',
      'Complete Developer Handoff with Strict Design Tokens'
    ],
    techStack: ['Figma', 'Tokens Studio', 'CSS Modern Variables', 'Framer', 'Storybook'],
    architectureSummary: 'Atomic design tokens mapped 1:1 to CSS custom properties and component libraries.',
    iconName: 'Palette',
    estimatedTimeline: '4 - 8 Minggu'
  }
];

export const CASE_STUDIES: CaseStudy[] = [
  {
    id: 'nexatrade-analytics',
    title: 'NexaTrade: Enterprise Cloud & Real-Time Trading Engine',
    client: 'Nexa Financial Capital',
    industry: 'Fintech & Capital Markets',
    category: 'web',
    summary: 'Platform analitik pasar modal dan eksekusi transaksi berbasis cloud dengan latensi mikrodetik dan visualisasi data real-time.',
    challenge: 'Klien menghadapi sistem lama yang sering freeze saat jam pembukaan bursa dan dashboard lambat memproses jutaan order book per detik.',
    solution: 'CV. Kafeinarts merancang ulang total arsitektur frontend dengan WebGL-accelerated canvas dan backend microservices berbasis Go dengan Redis stream.',
    architecture: [
      'Distributed WebSocket cluster with multi-region failover',
      'Sub-15ms order book streaming ingestion',
      'Hardware-accelerated charting engine running at 60 FPS'
    ],
    techStack: ['Next.js', 'TypeScript', 'Go', 'Redis', 'PostgreSQL', 'AWS'],
    impactMetrics: [
      { label: 'Latency Drop', value: '-82%', trend: 'Dari 120ms ke 21ms' },
      { label: 'Concurrent Users', value: '250K+', trend: 'Zero Downtime' },
      { label: 'Crash Rate', value: '0.00%', trend: '99.999% Availability' }
    ],
    image: '/images/mockup-saas.jpg',
    featured: true
  },
  {
    id: 'voltpay-mobile',
    title: 'VoltPay: Next-Gen Biometric Crypto & Fiat Mobile Wallet',
    client: 'Volt Payment Network',
    industry: 'Mobile Fintech',
    category: 'mobile',
    summary: 'Aplikasi mobile dompet digital multi-aset dengan otorisasi biometrik instan, transfer QR interaktif, dan enkripsi berstandar perbankan.',
    challenge: 'Aplikasi mobile versi lama memiliki tingkat drop-off tinggi pada tahap otorisasi pembayaran dan proses sinkronisasi saldo yang lambat.',
    solution: 'Membangun ulang aplikasi menggunakan Flutter Clean Architecture dengan modul keamanan biometrik native dan WebSocket streaming update.',
    architecture: [
      'Local Secure Enclave & Keystore hardware encryption',
      'Offline-capable transaction queue with auto-retry sync',
      'Biometric authentication completed under 200ms'
    ],
    techStack: ['Flutter', 'Dart', 'Kotlin', 'Swift', 'Node.js', 'Docker'],
    impactMetrics: [
      { label: 'App Rating', value: '4.9/5', trend: 'Di App Store & Play' },
      { label: 'Drop-off Reduction', value: '43%', trend: 'Konversi Checkout Naik' },
      { label: 'Transaction Speed', value: '0.8s', trend: 'Instant Settlement' }
    ],
    image: '/images/mockup-mobile.jpg',
    featured: true
  },
  {
    id: 'logixflow-erp',
    title: 'LogixFlow: Cloud-Native Logistics & Fleet Operations ERP',
    client: 'TransPacific Logistics Group',
    industry: 'Supply Chain & Enterprise',
    category: 'enterprise',
    summary: 'Sistem ERP operasional terpadu yang memantau 1.200 armada truk ekspedisi secara real-time di seluruh Indonesia.',
    challenge: 'Data armada terpisah-pisah di berbagai spreadsheet manual, menyebabkan inefisiensi bahan bakar dan keterlambatan pengiriman paket.',
    solution: 'Membangun web platform operasional berbasis peta interaktif dengan algoritma rute dinamis, dispatching otomatis, dan integrasi sensor IoT.',
    architecture: [
      'IoT Telemetry receiver ingesting 50,000 GPS pings/minute',
      'Dynamic heuristic routing algorithm reducing fuel consumption',
      'Automated dispatching engine with driver mobile app companion'
    ],
    techStack: ['React', 'TypeScript', 'Python', 'FastAPI', 'PostgreSQL PostGIS', 'Kubernetes'],
    impactMetrics: [
      { label: 'Fleet Efficiency', value: '+35%', trend: 'Optimasi Rute Armada' },
      { label: 'Cost Savings', value: 'Rp 1.4 M', trend: 'Penghematan Bahan Bakar / Thn' },
      { label: 'On-Time Rate', value: '98.7%', trend: 'Meningkat dari 84%' }
    ],
    image: '/images/skyline.jpg',
    featured: false
  }
];

export const WORKFLOW_STAGES: WorkflowStage[] = [
  {
    step: '01',
    title: 'Discovery & Blueprinting',
    subtitle: 'SRS, Arsitektur Sistem & Estimasi RAB Presisi',
    description: 'Kami menyelami model bisnis, tantangan teknis, dan target pengguna Anda. Menghasilkan dokumen Software Requirement Specification (SRS) komprehensif, arsitektur database, dan timeline sprint transparan.',
    outputs: ['Software Requirement Specification (SRS)', 'Database Schema & API Contract', 'Detailed Sprint Roadmap & RAB Fixed-Cost'],
    duration: '1 - 2 Minggu',
    accent: '#f59e0b'
  },
  {
    step: '02',
    title: 'UI/UX & System Architecture',
    subtitle: 'Design System Berkelas & Prototyping Interaktif',
    description: 'Merancang antarmuka visual anti-AI slop yang elegan, intuitif, dan selaras dengan identitas brand Anda. Dilengkapi design system modular dan uji alur pengguna sebelum satu baris kode pun ditulis.',
    outputs: ['Interactive High-Fidelity Figma Prototype', 'Atomic Design System & Component Guidelines', 'User Journey & Usability Validation'],
    duration: '2 - 3 Minggu',
    accent: '#38bdf8'
  },
  {
    step: '03',
    title: 'Agile Sprints & Clean Code',
    subtitle: 'Iterasi 2 Mingguan dengan Demo Langsung',
    description: 'Eksekusi rekayasa kode dengan standar Clean Architecture dan zero technical debt. Setiap akhir sprint 2 mingguan, Anda mendapatkan staging demo yang bisa langsung diuji dan dievaluasi.',
    outputs: ['Bi-Weekly Live Staging Deployments', 'Clean, Documented Code Repository', 'Sprint Review & Collaborative Backlog Refinement'],
    duration: '4 - 12 Minggu',
    accent: '#10b981'
  },
  {
    step: '04',
    title: 'Rigorous QA & Security Audit',
    subtitle: 'Automated Testing, Stress Test & Pentest',
    description: 'Pengujian komprehensif tanpa kompromi. Mencakup automated unit test, end-to-end integration test, benchmark beban traffic ekstrim (stress testing), serta audit celah keamanan OWASP.',
    outputs: ['OWASP Top 10 Security Audit Report', 'Stress & Load Testing Performance Log', 'Cross-Browser & Multi-Device QA Clearance'],
    duration: '1 - 2 Minggu',
    accent: '#a855f7'
  },
  {
    step: '05',
    title: 'Production Launch & 24/7 SLA',
    subtitle: 'Zero-Downtime Deployment & Garansi Bug',
    description: 'Peluncuran mulus ke server production dengan automated CI/CD pipeline. Kami mendampingi masa transisi, memberikan pelatihan tim, dan menyediakan garansi bug gratis serta dukungan SLA teknis.',
    outputs: ['Zero-Downtime Live Production Deployment', '100% Full Source Code & IP Handoff', 'Free Bug Warranty & 24/7 SLA Maintenance'],
    duration: 'Ongoing Support',
    accent: '#00f2fe'
  }
];

export const FAQS_DATA: FAQItem[] = [
  {
    question: 'Apakah source code dan hak cipta (IP) menjadi milik klien 100%?',
    answer: 'Ya, mutlak 100%! Setelah pembayaran proyek diselesaikan, seluruh hak cipta kekayaan intelektual (IP), repository Git source code, akses server, database, dan seluruh aset desain diserahkan sepenuhnya kepada Anda tanpa royalti tersembunyi.',
    category: 'Legal & Ownership'
  },
  {
    question: 'Bagaimana skema pembayaran di CV. Kafeinarts?',
    answer: 'Kami menerapkan skema pembayaran bertahap (Milestone-based Payments) yang transparan dan aman bagi kedua belah pihak. Umumnya dibagi menjadi 3-4 termin: Down Payment (DP) awal, pencapaian milestone fungsional utama, dan pelunasan saat Final User Acceptance Test (UAT).',
    category: 'Pricing & Terms'
  },
  {
    question: 'Apakah ada garansi jika terdapat bug setelah sistem rilis?',
    answer: 'Tentu saja. Setiap proyek yang kami selesaikan mendapatkan periode Garansi Bug Resmi (Bug-Fixing Warranty) gratis selama 30 hingga 90 hari kalender. Tim kami akan sigap memperbaiki anomali fungsional tanpa biaya tambahan.',
    category: 'Support & Warranty'
  },
  {
    question: 'Bagaimana jika kami membutuhkan penambahan fitur di tengah jalan?',
    answer: 'Kami mengadopsi metodologi Agile. Setiap perubahan atau penambahan fitur dapat dinegosiasikan secara fleksibel melalui Change Request (CR) transparan dengan kalkulasi estimasi waktu dan biaya yang disepakati bersama sebelum dikerjakan.',
    category: 'Development Process'
  },
  {
    question: 'Apakah CV. Kafeinarts menyediakan layanan pemeliharaan server (SLA/Maintenance)?',
    answer: 'Ya! Kami menyediakan paket SLA Maintenance bulanan/tahunan yang mencakup monitoring server 24/7, optimasi database berkala, backup harian otomatis, pembaruan patch keamanan, dan jaminan respon darurat dalam waktu singkat.',
    category: 'Infrastructure & SLA'
  }
];

export const TECH_RADAR = [
  { name: 'React 19 / Next.js', category: 'Frontend', status: 'Core Adoption', icon: 'Atom' },
  { name: 'TypeScript', category: 'Frontend', status: 'Strict Standard', icon: 'Code' },
  { name: 'Tailwind CSS & WebGL', category: 'Frontend', status: 'Design System', icon: 'Layout' },
  { name: 'Go (Golang)', category: 'Backend', status: 'High Throughput', icon: 'Cpu' },
  { name: 'Node.js / NestJS', category: 'Backend', status: 'Microservices', icon: 'Server' },
  { name: 'Python / FastAPI', category: 'Backend', status: 'AI & Data Engine', icon: 'Terminal' },
  { name: 'PostgreSQL & Redis', category: 'Database', status: 'Primary Cluster', icon: 'Database' },
  { name: 'Flutter & Kotlin', category: 'Mobile', status: 'Cross & Native', icon: 'Smartphone' },
  { name: 'AWS & Kubernetes', category: 'DevOps', status: 'Cloud Native', icon: 'Cloud' },
  { name: 'Docker & CI/CD', category: 'DevOps', status: 'Automated Delivery', icon: 'Boxes' }
];
