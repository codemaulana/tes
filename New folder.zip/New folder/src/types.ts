export interface Service {
  id: string;
  number: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  deliverables: string[];
  techStack: string[];
  architectureSummary: string;
  iconName: string;
  estimatedTimeline: string;
  tag: string;
}

export interface CaseStudy {
  id: string;
  title: string;
  client: string;
  industry: string;
  category: 'web' | 'mobile' | 'enterprise';
  summary: string;
  challenge: string;
  solution: string;
  architecture: string[];
  techStack: string[];
  impactMetrics: {
    label: string;
    value: string;
    trend: string;
  }[];
  image: string;
  featured?: boolean;
}

export interface WorkflowStage {
  step: string;
  title: string;
  subtitle: string;
  description: string;
  outputs: string[];
  duration: string;
  accent: string;
}

export interface TechItem {
  name: string;
  category: 'frontend' | 'backend' | 'devops' | 'mobile' | 'ai';
  level: string;
  icon: string;
  description: string;
}

export interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

export interface EstimatorState {
  platform: 'web' | 'mobile' | 'enterprise' | 'ai';
  scale: 'mvp' | 'growth' | 'enterprise';
  features: string[];
  timelineWeeks: [number, number];
  estimatedBudget: [number, number];
}
