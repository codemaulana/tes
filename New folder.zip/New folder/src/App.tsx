import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { ParticleCanvas } from './components/ParticleCanvas';
import { HeroParallax } from './components/HeroParallax';
import { BrandShowcase } from './components/BrandShowcase';
import { ServicesEngine } from './components/ServicesEngine';
import { PortfolioShowcase } from './components/PortfolioShowcase';
import { WorkflowTimeline } from './components/WorkflowTimeline';
import { TechRadar } from './components/TechRadar';
import { ProjectEstimator } from './components/ProjectEstimator';
import { TestimonialsFAQ } from './components/TestimonialsFAQ';
import { InquirySection } from './components/InquirySection';
import { Footer } from './components/Footer';

export const App: React.FC = () => {
  const [selectedPlatform, setSelectedPlatform] = useState<string>('web');

  const handleSelectServiceForEstimator = (platform: string) => {
    setSelectedPlatform(platform);
  };

  return (
    <div className="min-h-screen bg-[#07080c] text-white selection:bg-[#f59e0b] selection:text-black relative">
      {/* Background Interactive Particle Canvas */}
      <ParticleCanvas />

      {/* Floating Glassmorphism Navbar */}
      <Navbar />

      <main className="relative z-10 flex flex-col items-center">
        {/* Hero Section with Multi-Plane Parallax Depth Zoom */}
        <HeroParallax />

        {/* Panoramic Skyline & Engineering Manifesto */}
        <BrandShowcase />

        {/* 6 Core IT Capabilities & Interactive Architecture Modal */}
        <ServicesEngine onSelectServiceForEstimator={handleSelectServiceForEstimator} />

        {/* Portfolio & Case Studies Deep Dive */}
        <PortfolioShowcase />

        {/* 5-Stage Sticky Development Workflow */}
        <WorkflowTimeline />

        {/* Production Tech Radar & Live Benchmarks */}
        <TechRadar />

        {/* Interactive Scope & Cost Estimator with WhatsApp Export */}
        <ProjectEstimator initialPlatform={selectedPlatform} />

        {/* Testimonials & FAQs Accordion */}
        <TestimonialsFAQ />

        {/* Project Inquiries & Briefing Form */}
        <InquirySection />
      </main>

      {/* Oversized Brand Typography Footer */}
      <Footer />
    </div>
  );
};

export default App;
