import React, { useEffect, useState, useRef } from 'react';
import { ArrowDown, Sparkles, Activity, ShieldCheck, ChevronRight } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

export const HeroParallax: React.FC = () => {
  const [scrollY, setScrollY] = useState(0);
  const heroRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let ticking = false;

    const onScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          setScrollY(window.scrollY);
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Calculate parallax ratios based on scroll
  const maxScroll = typeof window !== 'undefined' ? window.innerHeight * 0.9 : 800;
  const progress = Math.min(1, Math.max(0, scrollY / maxScroll));

  // Transform values for multi-plane depth
  const buildingScale = 1 + progress * 0.32;
  const buildingY = progress * -65;
  const textY = progress * -120;
  const textOpacity = Math.max(0, 1 - progress * 1.35);
  const cloudOffset = progress * -45;

  return (
    <section
      ref={heroRef}
      className="relative min-h-[140vh] w-full flex flex-col items-center justify-start pt-32 sm:pt-40 px-4 overflow-hidden"
    >
      {/* Background Ambient Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-b from-[#f59e0b]/15 via-[#38bdf8]/5 to-transparent rounded-full blur-[130px] pointer-events-none -z-10" />
      <div className="absolute top-1/3 left-1/4 w-[350px] h-[350px] bg-[#d97706]/10 rounded-full blur-[100px] pointer-events-none -z-10" />

      {/* Layer 1: Headline & Subtitle Layer (Moves faster and fades) */}
      <div
        className="w-full max-w-5xl mx-auto text-center flex flex-col items-center gap-5 z-20 pointer-events-auto transition-transform duration-75 will-change-transform"
        style={{
          transform: `translate3d(0, ${textY}px, 0)`,
          opacity: textOpacity,
        }}
      >
        {/* Status Pill Badge */}
        <div className="badge-tag !py-1.5 !px-4 shadow-lg shadow-black/40">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" style={{ animationDuration: '6s' }} />
          <span>Bespoke IT Solutions & Software House</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse ml-1" />
        </div>

        {/* Main Architectural Headline */}
        <h1 className="font-display font-black text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tight leading-[1.08] text-white">
          Brewing <span className="bg-gradient-to-r from-[#f59e0b] via-[#fbbf24] to-[#fde68a] bg-clip-text text-transparent">Digital Mastery</span>
          <br className="hidden sm:inline" /> for Visionary Brands.
        </h1>

        {/* Crisp Sub-copy */}
        <p className="max-w-2xl text-slate-300 text-sm sm:text-lg font-normal leading-relaxed mt-1">
          Kami merekayasa web apps berskala tinggi, aplikasi mobile native, dan arsitektur cloud tahan banting. Bersih dari AI slop, dirancang khusus untuk keunggulan teknologi jangka panjang.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 mt-3">
          <a href="#estimator" className="btn-gold !py-3.5 !px-7 text-sm font-bold shadow-xl shadow-amber-500/20">
            <span>Hitung Estimasi Biaya</span>
            <ChevronRight className="w-4 h-4" />
          </a>
          <a href="#portfolio" className="btn-secondary !py-3.5 !px-6 text-sm">
            <span>Eksplorasi Studi Kasus</span>
          </a>
        </div>
      </div>

      {/* Layer 2: The 3D Digital Core Masterpiece (Scales & Elevates like in Video) */}
      <div className="relative w-full max-w-4xl mx-auto mt-8 sm:mt-12 flex flex-col items-center justify-center z-10">
        
        {/* Floating Telemetry Badge Left */}
        <div
          className="hidden md:flex absolute -left-6 top-1/4 z-30 glass-panel !bg-[#0b0e17]/85 !p-3.5 items-center gap-3 border border-white/10 shadow-2xl transition-transform duration-100 will-change-transform"
          style={{
            transform: `translate3d(0, ${buildingY * 1.2}px, 0)`,
          }}
        >
          <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Activity className="w-4 h-4 animate-pulse" />
          </div>
          <div className="text-left font-mono-code">
            <div className="text-[10px] text-slate-400 uppercase tracking-widest">Core Latency</div>
            <div className="text-xs font-bold text-cyan-400 flex items-center gap-1">
              14.2 ms <span className="text-[9px] text-emerald-400 font-normal">● Optimal</span>
            </div>
          </div>
        </div>

        {/* Floating Telemetry Badge Right */}
        <div
          className="hidden md:flex absolute -right-6 top-1/3 z-30 glass-panel !bg-[#0b0e17]/85 !p-3.5 items-center gap-3 border border-white/10 shadow-2xl transition-transform duration-100 will-change-transform"
          style={{
            transform: `translate3d(0, ${buildingY * 0.9}px, 0)`,
          }}
        >
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div className="text-left font-mono-code">
            <div className="text-[10px] text-slate-400 uppercase tracking-widest">SLA Availability</div>
            <div className="text-xs font-bold text-amber-400">
              99.99% <span className="text-[9px] text-slate-400 font-normal">ISO Ready</span>
            </div>
          </div>
        </div>

        {/* The 3D Centerpiece Visual with Depth Zooming */}
        <div
          className="relative w-full aspect-square max-w-[620px] rounded-3xl overflow-visible transition-transform duration-75 ease-out will-change-transform"
          style={{
            transform: `translate3d(0, ${buildingY}px, 0) scale(${buildingScale})`,
          }}
        >
          {/* Subtle Ambient Radial Backlight behind the 3D Building */}
          <div className="absolute inset-4 -bottom-6 bg-gradient-to-t from-[#f59e0b]/25 via-cyan-500/10 to-transparent rounded-full blur-2xl -z-10" />

          {/* High-Resolution 3D Architectural Asset */}
          <img
            src="/images/hero-core.jpg"
            alt="CV. Kafeinarts 3D Digital Architecture Core"
            className="w-full h-full object-contain filter drop-shadow-[0_25px_45px_rgba(0,0,0,0.85)] select-none pointer-events-none"
            loading="eager"
          />

          {/* Floating Atmospheric Cloud & Fog Layers (Multi-plane effect) */}
          <div
            className="absolute -bottom-10 -inset-x-12 h-36 bg-gradient-to-t from-[#07080c] via-[#07080c]/80 to-transparent pointer-events-none transition-transform duration-100"
            style={{ transform: `translate3d(0, ${cloudOffset}px, 0)` }}
          />
        </div>

        {/* Scroll Indicator Prompt */}
        <div className="mt-2 flex flex-col items-center gap-2 opacity-70 animate-bounce duration-1000">
          <span className="text-[11px] font-mono-code tracking-widest uppercase text-slate-400">
            Scroll to Explore Depth
          </span>
          <ArrowDown className="w-4 h-4 text-amber-400" />
        </div>
      </div>

      {/* Layer 3: Live Metrics & Telemetry Bar */}
      <div className="w-full max-w-6xl mx-auto mt-20 sm:mt-28 z-20">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 p-4 sm:p-6 rounded-2xl bg-[#0c0f18]/80 backdrop-blur-xl border border-white/10 shadow-2xl">
          {COMPANY_INFO.metrics.map((metric, i) => (
            <div
              key={i}
              className="flex flex-col p-3 sm:p-4 rounded-xl bg-white/[0.02] border border-white/5 hover:border-amber-500/30 transition-colors"
            >
              <span className="font-display font-black text-2xl sm:text-3xl text-transparent bg-gradient-to-r from-white via-slate-100 to-amber-200 bg-clip-text">
                {metric.value}
              </span>
              <span className="text-xs sm:text-sm font-semibold text-slate-200 mt-1">
                {metric.label}
              </span>
              <span className="text-[11px] font-mono-code text-slate-400 mt-0.5">
                {metric.detail}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
