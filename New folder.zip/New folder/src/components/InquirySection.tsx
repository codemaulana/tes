import React, { useState } from 'react';
import { Send, MessageCircle, Mail, MapPin, CheckCircle, ArrowRight, ShieldCheck } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

export const InquirySection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    projectType: 'Web Application',
    budgetRange: 'Rp 20 Jt - 50 Jt',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    // Open WhatsApp pre-filled with the contact inquiry
    const msg = `Halo ${COMPANY_INFO.name}, saya ingin mengirim inquiry proyek:
- Nama: ${formData.name}
- Perusahaan: ${formData.company || '-'}
- Email: ${formData.email}
- No. WhatsApp: ${formData.phone}
- Kategori Proyek: ${formData.projectType}
- Rencana Investasi: ${formData.budgetRange}
- Brief Kebutuhan: ${formData.message}`;

    const encoded = encodeURIComponent(msg);
    setTimeout(() => {
      window.open(`https://wa.me/${COMPANY_INFO.whatsappNumber}?text=${encoded}`, '_blank');
    }, 600);
  };

  return (
    <section id="contact" className="relative w-full max-w-7xl mx-auto px-4 py-24 sm:py-32">
      {/* Background glow */}
      <div className="absolute bottom-10 right-1/4 w-80 h-80 bg-amber-500/10 rounded-full blur-[130px] pointer-events-none -z-10" />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        {/* Left Information */}
        <div className="lg:col-span-5 flex flex-col justify-between">
          <div>
            <div className="badge-tag !py-1 !px-3 mb-4">
              <Mail className="w-3.5 h-3.5 text-amber-400" />
              <span>Project Inquiries</span>
            </div>

            <h2 className="font-display font-black text-3xl sm:text-5xl text-white tracking-tight leading-tight">
              Mulai Konsultasi <br />
              <span className="text-[#f59e0b]">Rekayasa Digital Anda</span>.
            </h2>

            <p className="text-slate-300 text-sm sm:text-base mt-4 leading-relaxed">
              Punya ide produk baru, kebutuhan transformasi sistem enterprise, atau ingin merekrut dedicated engineering team? Mari jadwalkan sesi technical briefing bersama kami.
            </p>

            <div className="mt-8 space-y-4">
              <div className="flex items-center gap-3.5 p-3.5 rounded-2xl bg-white/[0.02] border border-white/5">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-mono-code text-slate-400 uppercase">Direct Email</div>
                  <div className="text-sm font-bold text-white">{COMPANY_INFO.email}</div>
                </div>
              </div>

              <div className="flex items-center gap-3.5 p-3.5 rounded-2xl bg-white/[0.02] border border-white/5">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                  <MessageCircle className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-mono-code text-slate-400 uppercase">Official WhatsApp Business</div>
                  <div className="text-sm font-bold text-white">+{COMPANY_INFO.whatsappNumber}</div>
                </div>
              </div>

              <div className="flex items-center gap-3.5 p-3.5 rounded-2xl bg-white/[0.02] border border-white/5">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-mono-code text-slate-400 uppercase">Studio & Engineering Base</div>
                  <div className="text-sm font-bold text-white">{COMPANY_INFO.location}</div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 p-4 rounded-2xl bg-cyan-500/5 border border-cyan-500/15 flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-cyan-400 shrink-0" />
            <div className="text-xs text-slate-300">
              Setiap diskusi kebutuhan bisnis dilindungi oleh klausul <strong className="text-white">Non-Disclosure Agreement (NDA)</strong> standar.
            </div>
          </div>
        </div>

        {/* Right Form Card */}
        <div className="lg:col-span-7">
          <div className="glass-panel !bg-[#0b0e17]/90 !p-8 sm:p-10 border border-white/10 shadow-2xl relative">
            {submitted ? (
              <div className="py-12 flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mb-4 animate-bounce">
                  <CheckCircle className="w-8 h-8" />
                </div>
                <h3 className="font-display font-bold text-2xl text-white mb-2">
                  Inquiry Berhasil Disiapkan!
                </h3>
                <p className="text-slate-300 text-sm max-w-md mb-6">
                  Browser Anda sedang membuka jendela WhatsApp resmi CV. Kafeinarts untuk memvalidasi briefing ini langsung dengan Lead Architect kami.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="btn-secondary !py-2 !px-4 text-xs"
                >
                  Kirim Briefing Baru
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                <h3 className="font-display font-bold text-xl text-white mb-1">
                  Kirimkan Briefing Proyek
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-mono-code text-slate-400 block mb-1.5">
                      Nama Lengkap *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Budi Santoso"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="glass-input w-full text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-mono-code text-slate-400 block mb-1.5">
                      Nama Perusahaan / Startup
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. PT. Mitra Inovasi"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      className="glass-input w-full text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-mono-code text-slate-400 block mb-1.5">
                      Alamat Email *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="budi@company.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="glass-input w-full text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-mono-code text-slate-400 block mb-1.5">
                      No. WhatsApp / Kontak *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="0812xxxxxxxx"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="glass-input w-full text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-mono-code text-slate-400 block mb-1.5">
                      Kategori Layanan
                    </label>
                    <select
                      value={formData.projectType}
                      onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                      className="glass-input w-full text-xs bg-[#0b0e17] text-white"
                    >
                      <option value="Web Application & SaaS">Web Application & SaaS</option>
                      <option value="Mobile App (iOS & Android)">Mobile App (iOS & Android)</option>
                      <option value="Enterprise ERP & Custom Software">Enterprise ERP & Custom Software</option>
                      <option value="AI Engine & API Automation">AI Engine & API Automation</option>
                      <option value="Cloud DevOps & Security">Cloud DevOps & Security</option>
                      <option value="UI/UX Product Design">UI/UX Product Design</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-mono-code text-slate-400 block mb-1.5">
                      Alokasi Budget
                    </label>
                    <select
                      value={formData.budgetRange}
                      onChange={(e) => setFormData({ ...formData, budgetRange: e.target.value })}
                      className="glass-input w-full text-xs bg-[#0b0e17] text-white"
                    >
                      <option value="Rp 20 Jt - Rp 50 Jt">Rp 20 Jt - Rp 50 Jt</option>
                      <option value="Rp 50 Jt - Rp 100 Jt">Rp 50 Jt - Rp 100 Jt</option>
                      <option value="Rp 100 Jt - Rp 250 Jt">Rp 100 Jt - Rp 250 Jt</option>
                      <option value="> Rp 250 Jt (Enterprise)">&gt; Rp 250 Jt (Enterprise)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-mono-code text-slate-400 block mb-1.5">
                    Ceritakan Singkat Rencana Proyek Anda *
                  </label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Jelaskan gambaran sistem yang ingin Anda bangun, target rilis, atau problem yang sedang dihadapi..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="glass-input w-full text-xs resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="btn-gold w-full justify-center !py-3.5 text-sm font-bold shadow-xl shadow-amber-500/20"
                >
                  <Send className="w-4 h-4 fill-black text-black" />
                  <span>Kirim Briefing & Terhubung ke WhatsApp</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
