import React, { useState, useMemo } from 'react';
import { Calculator, Check, ArrowRight, MessageCircle, Sparkles } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

interface ProjectEstimatorProps {
  initialPlatform?: string;
}

export const ProjectEstimator: React.FC<ProjectEstimatorProps> = ({ initialPlatform = 'web' }) => {
  const [platform, setPlatform] = useState<'web' | 'mobile' | 'enterprise' | 'ai'>(
    (initialPlatform as any) || 'web'
  );
  const [scale, setScale] = useState<'mvp' | 'growth' | 'enterprise'>('mvp');
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([
    'auth',
    'admin'
  ]);

  // Platforms definitions
  const platforms = [
    { id: 'web', name: 'Web Application / SaaS', basePrice: 20000000, baseWeeks: 5 },
    { id: 'mobile', name: 'Mobile App (iOS & Android)', basePrice: 28000000, baseWeeks: 6 },
    { id: 'enterprise', name: 'Enterprise ERP / CRM', basePrice: 45000000, baseWeeks: 9 },
    { id: 'ai', name: 'AI Engine & Cloud Core', basePrice: 35000000, baseWeeks: 7 },
  ];

  // Scale multipliers
  const scales = [
    {
      id: 'mvp',
      name: 'MVP (Stage 1)',
      desc: 'Peluncuran cepat untuk validasi pasar & investor',
      multiplier: 1.0,
      weekAdd: 0
    },
    {
      id: 'growth',
      name: 'Growth Scale',
      desc: 'Trafik menengah, optimasi performa & integrasi luas',
      multiplier: 1.45,
      weekAdd: 3
    },
    {
      id: 'enterprise',
      name: 'Enterprise Core',
      desc: 'Multi-tenant, SLA 99.99%, audit keamanan ISO & on-premise',
      multiplier: 2.1,
      weekAdd: 6
    },
  ];

  // Feature addons
  const featuresList = [
    { id: 'auth', name: 'Role-Based Access Control (RBAC) & OAuth', price: 4000000, weeks: 1 },
    { id: 'payment', name: 'Payment Gateway (Midtrans, Xendit, Stripe)', price: 5000000, weeks: 1 },
    { id: 'realtime', name: 'Real-time WebSocket & Live Push Sync', price: 6500000, weeks: 1.5 },
    { id: 'admin', name: 'Comprehensive Admin Analytics Dashboard', price: 6000000, weeks: 1 },
    { id: 'ai-feature', name: 'Private RAG & Custom LLM Integration', price: 9000000, weeks: 2 },
    { id: 'devops', name: 'Docker, CI/CD Pipeline & High Security Hardening', price: 5500000, weeks: 1 },
  ];

  const toggleFeature = (featureId: string) => {
    setSelectedFeatures((prev) =>
      prev.includes(featureId) ? prev.filter((id) => id !== featureId) : [...prev, featureId]
    );
  };

  // Calculate pricing & timeline
  const calculation = useMemo(() => {
    const currentPlatform = platforms.find((p) => p.id === platform) || platforms[0];
    const currentScale = scales.find((s) => s.id === scale) || scales[0];

    const featuresCost = selectedFeatures.reduce((acc, featId) => {
      const feat = featuresList.find((f) => f.id === featId);
      return acc + (feat ? feat.price : 0);
    }, 0);

    const featuresWeeks = selectedFeatures.reduce((acc, featId) => {
      const feat = featuresList.find((f) => f.id === featId);
      return acc + (feat ? feat.weeks : 0);
    }, 0);

    const baseSum = currentPlatform.basePrice * currentScale.multiplier + featuresCost;
    const minBudget = Math.round(baseSum / 1000000) * 1000000;
    const maxBudget = Math.round((baseSum * 1.25) / 1000000) * 1000000;

    const baseDuration = currentPlatform.baseWeeks + currentScale.weekAdd + Math.round(featuresWeeks * 0.7);
    const minWeeks = Math.max(3, baseDuration);
    const maxWeeks = minWeeks + 2;

    return {
      minBudget,
      maxBudget,
      minWeeks,
      maxWeeks,
      platformName: currentPlatform.name,
      scaleName: currentScale.name,
    };
  }, [platform, scale, selectedFeatures]);

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(val);
  };

  const handleSendToWhatsApp = () => {
    const activeFeatNames = selectedFeatures
      .map((id) => featuresList.find((f) => f.id === id)?.name)
      .filter(Boolean)
      .join('\n  - ');

    const message = `Halo ${COMPANY_INFO.name}, saya menggunakan Kalkulator Estimasi di website dan ingin berdiskusi mengenai proyek berikut:

*Rincian Scope Proyek:*
- Platform: ${calculation.platformName}
- Skala Kebutuhan: ${calculation.scaleName}
- Fitur Tambahan Terpilih:
  - ${activeFeatNames || 'Tanpa addon tambahan'}
- Perkiraan Timeline: ${calculation.minWeeks} - ${calculation.maxWeeks} Minggu
- Perkiraan Budget: ${formatRupiah(calculation.minBudget)} - ${formatRupiah(calculation.maxBudget)}

Apakah tim Kafeinarts bersedia untuk sesi discovery call atau briefing SRS awal?`;

    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/${COMPANY_INFO.whatsappNumber}?text=${encoded}`, '_blank');
  };

  return (
    <section id="estimator" className="relative w-full max-w-7xl mx-auto px-4 py-24 sm:py-32">
      {/* Glow highlight behind container */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 bg-amber-500/5 blur-[120px] pointer-events-none -z-10" />

      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <div className="badge-tag !py-1 !px-3 mb-3">
          <Calculator className="w-3.5 h-3.5 text-amber-400" />
          <span>Interactive Cost & Scope Calculator</span>
        </div>
        <h2 className="font-display font-black text-3xl sm:text-5xl text-white tracking-tight">
          Hitung Estimasi Biaya & <br />
          <span className="text-[#f59e0b]">Timeline Proyek Anda</span>
        </h2>
        <p className="text-slate-300 text-sm sm:text-base mt-3">
          Transparansi harga tanpa biaya tersembunyi. Tentukan platform, skala, dan fitur yang Anda butuhkan, dapatkan proyeksi investasi secara instan.
        </p>
      </div>

      {/* Estimator Engine Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Inputs (7 Columns) */}
        <div className="lg:col-span-7 flex flex-col gap-8">
          
          {/* 1. Select Platform */}
          <div className="glass-panel !bg-[#0b0e17]/85 !p-6 border border-white/10">
            <label className="text-xs font-mono-code uppercase tracking-wider text-amber-400 block mb-4 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center text-[10px] font-bold border border-amber-500/30">
                1
              </span>
              <span>Pilih Jenis Platform</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {platforms.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPlatform(p.id as any)}
                  className={`p-4 rounded-xl text-left border transition-all ${
                    platform === p.id
                      ? 'bg-amber-500/10 border-amber-500/60 shadow-lg shadow-amber-500/10'
                      : 'bg-white/[0.02] border-white/5 hover:border-white/20'
                  }`}
                >
                  <div className="font-display font-bold text-sm text-white">{p.name}</div>
                  <div className="text-[11px] font-mono-code text-slate-400 mt-1">
                    Mulai dari {formatRupiah(p.basePrice)}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* 2. Select Scale */}
          <div className="glass-panel !bg-[#0b0e17]/85 !p-6 border border-white/10">
            <label className="text-xs font-mono-code uppercase tracking-wider text-amber-400 block mb-4 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center text-[10px] font-bold border border-amber-500/30">
                2
              </span>
              <span>Skala & Kompleksitas Sistem</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {scales.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setScale(s.id as any)}
                  className={`p-4 rounded-xl text-left border transition-all flex flex-col justify-between ${
                    scale === s.id
                      ? 'bg-amber-500/10 border-amber-500/60 shadow-lg shadow-amber-500/10'
                      : 'bg-white/[0.02] border-white/5 hover:border-white/20'
                  }`}
                >
                  <div>
                    <div className="font-display font-bold text-sm text-white">{s.name}</div>
                    <div className="text-[11px] text-slate-300 mt-1 leading-snug">{s.desc}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* 3. Addon Features */}
          <div className="glass-panel !bg-[#0b0e17]/85 !p-6 border border-white/10">
            <label className="text-xs font-mono-code uppercase tracking-wider text-amber-400 block mb-4 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center text-[10px] font-bold border border-amber-500/30">
                3
              </span>
              <span>Pilih Modul & Fitur Spesifik</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {featuresList.map((f) => {
                const isChecked = selectedFeatures.includes(f.id);
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => toggleFeature(f.id)}
                    className={`p-3.5 rounded-xl text-left border transition-all flex items-start gap-3 ${
                      isChecked
                        ? 'bg-cyan-500/10 border-cyan-500/50 shadow-md shadow-cyan-500/10'
                        : 'bg-white/[0.02] border-white/5 hover:border-white/15'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-md mt-0.5 flex items-center justify-center transition-colors ${
                        isChecked ? 'bg-cyan-400 text-black' : 'border border-white/30'
                      }`}
                    >
                      {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-white">{f.name}</div>
                      <div className="text-[11px] font-mono-code text-slate-400 mt-0.5">
                        +{formatRupiah(f.price)} (~{f.weeks} mgg)
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Output Card Sticky (5 Columns) */}
        <div className="lg:col-span-5 sticky top-28">
          <div className="glass-panel !bg-[#0e121c]/95 !p-8 border border-amber-500/30 shadow-2xl relative overflow-hidden">
            {/* Ambient Corner Glow */}
            <div className="absolute -top-16 -right-16 w-36 h-36 bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-center justify-between pb-6 border-b border-white/10 mb-6">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span className="font-mono-code text-xs uppercase tracking-wider text-slate-300">
                  Estimasi Blueprint
                </span>
              </div>
              <span className="badge-cyan text-[10px]">Real-Time Calculated</span>
            </div>

            {/* Estimated Budget Range */}
            <div className="mb-6">
              <span className="text-xs font-mono-code text-slate-400 block mb-1">
                Estimasi Investasi (IDR)
              </span>
              <div className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight">
                {formatRupiah(calculation.minBudget)}
              </div>
              <div className="text-xs text-amber-400/90 font-mono-code mt-0.5">
                s/d {formatRupiah(calculation.maxBudget)}
              </div>
            </div>

            {/* Estimated Timeline */}
            <div className="mb-8 p-4 rounded-xl bg-white/[0.03] border border-white/5 flex items-center justify-between">
              <div>
                <span className="text-xs font-mono-code text-slate-400 block">
                  Perkiraan Durasi Pengerjaan
                </span>
                <span className="font-display font-bold text-lg text-white">
                  {calculation.minWeeks} - {calculation.maxWeeks} Minggu
                </span>
              </div>
              <div className="text-right">
                <span className="badge-tag text-[10px]">Agile Sprints</span>
              </div>
            </div>

            {/* What's included summary */}
            <div className="mb-8 space-y-2 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>100% Hak Cipta & Source Code Git milik Klien</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Garansi Bug-Fixing Resmi 60 Hari Kalender</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Setup CI/CD Pipeline & Server Production</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col gap-3">
              <button
                onClick={handleSendToWhatsApp}
                className="btn-gold w-full justify-center !py-3.5 shadow-xl shadow-amber-500/20"
              >
                <MessageCircle className="w-4 h-4 fill-black text-black" />
                <span>Konsultasikan via WhatsApp</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <p className="text-[11px] text-center text-slate-400 font-mono-code">
                Estimasi final disesuaikan dengan SRS formal dan dokumen kesepakatan bersama.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
