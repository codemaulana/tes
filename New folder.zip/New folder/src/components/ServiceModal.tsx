import React from 'react';
import { X, CheckCircle2, Cpu, Clock, Layers, ArrowRight, MessageCircle } from 'lucide-react';
import { Service } from '../types';
import { COMPANY_INFO } from '../data/content';

interface ServiceModalProps {
  service: Service | null;
  onClose: () => void;
  onSelectForEstimator: (serviceId: string) => void;
}

export const ServiceModal: React.FC<ServiceModalProps> = ({
  service,
  onClose,
  onSelectForEstimator,
}) => {
  if (!service) return null;

  const handleWhatsAppInquiry = () => {
    const text = encodeURIComponent(
      `Halo Tim ${COMPANY_INFO.name}, saya tertarik dengan layanan "${service.title}". Boleh jelaskan ketersediaan sprint dan rancangan blueprintnya?`
    );
    window.open(`https://wa.me/${COMPANY_INFO.whatsappNumber}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-[#0d1017] border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          aria-label="Tutup Modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-3">
          <span className="font-mono-code text-xs px-2.5 py-1 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            SERVICE {service.number}
          </span>
          <span className="badge-cyan text-[11px] !py-0.5 !px-2">{service.tag}</span>
        </div>

        <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-white mb-4">
          {service.title}
        </h2>

        <p className="text-slate-300 text-sm leading-relaxed mb-6">
          {service.fullDesc}
        </p>

        {/* Architecture Summary Box */}
        <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 mb-6 flex items-start gap-3">
          <Layers className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <h3 className="text-xs font-mono-code uppercase tracking-wider text-cyan-400 mb-1">
              Rancangan Arsitektur Inti
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              {service.architectureSummary}
            </p>
          </div>
        </div>

        {/* Deliverables Checklist */}
        <div className="mb-6">
          <h3 className="text-sm font-display font-bold text-white uppercase tracking-wider mb-3">
            Apa yang Klien Dapatkan (Key Deliverables):
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {service.deliverables.map((item, idx) => (
              <div
                key={idx}
                className="flex items-start gap-2.5 p-2.5 rounded-xl bg-white/[0.015] border border-white/5"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span className="text-xs text-slate-300 font-medium">{item}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Tech Stack Chips & Estimated Timeline */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-white/10 mb-8">
          <div>
            <div className="text-xs font-mono-code text-slate-400 mb-2 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-amber-400" />
              <span>Teknologi Utama</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {service.techStack.map((tech) => (
                <span
                  key={tech}
                  className="px-2.5 py-1 text-[11px] font-mono-code rounded-lg bg-white/5 text-slate-200 border border-white/10"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          <div>
            <div className="text-xs font-mono-code text-slate-400 mb-2 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>Estimasi Timeline Rilis</span>
            </div>
            <div className="text-sm font-bold text-white font-mono-code">
              {service.estimatedTimeline}
            </div>
          </div>
        </div>

        {/* Modal Action CTA */}
        <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-4 border-t border-white/10">
          <button
            onClick={() => {
              onClose();
              onSelectForEstimator(service.id);
            }}
            className="w-full sm:w-auto btn-secondary !py-2.5 !px-5 text-xs justify-center"
          >
            <span>Hitung Estimasi di Kalkulator</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleWhatsAppInquiry}
            className="w-full sm:w-auto btn-gold !py-2.5 !px-5 text-xs justify-center"
          >
            <MessageCircle className="w-3.5 h-3.5 fill-black text-black" />
            <span>Diskusi Teknis via WhatsApp</span>
          </button>
        </div>
      </div>
    </div>
  );
};
