import React, { useState } from 'react';
import { HelpCircle, ChevronDown, Quote, Star, MessageSquare } from 'lucide-react';
import { FAQS_DATA } from '../data/content';

export const TestimonialsFAQ: React.FC = () => {
  const [openFAQ, setOpenFAQ] = useState<number | null>(0);

  const testimonials = [
    {
      quote:
        'Kafeinarts merombak seluruh platform trading core kami. Latensi turun dari 120ms ke 21ms dan tidak ada downtime satu detik pun saat peak market. Tim engineer yang paling mengerti arsitektur distributed system.',
      author: 'Hendrik Pratama',
      role: 'Chief Technology Officer (CTO)',
      company: 'Nexa Financial Capital',
      rating: 5,
    },
    {
      quote:
        'Aplikasi mobile wallet kami selesai tepat waktu dengan bug rate mendekati nol. Standar UI/UX-nya sangat berkelas, bukan template AI murahan. Sangat recommended untuk startup yang butuh eksekusi cepat dan solid.',
      author: 'Clarissa Salim',
      role: 'Head of Product',
      company: 'VoltPay Network',
      rating: 5,
    },
    {
      quote:
        'Sistem fleet logistics Kafeinarts berhasil menghemat Rp 1.4 Miliar pengeluaran bahan bakar operasional kami di tahun pertama. Kode mereka rapi dan tim internal kami sangat mudah melakukan adaptasi.',
      author: 'Bambang Triyono',
      role: 'VP of Operations',
      company: 'TransPacific Group',
      rating: 5,
    },
  ];

  return (
    <section id="faq" className="relative w-full max-w-7xl mx-auto px-4 py-24 sm:py-32">
      {/* Testimonials Section */}
      <div className="mb-28">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="badge-tag !py-1 !px-3 mb-3">
            <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
            <span>Client Endorsements</span>
          </div>
          <h2 className="font-display font-black text-3xl sm:text-5xl text-white tracking-tight">
            Kepercayaan dari Para <br />
            <span className="text-[#f59e0b]">Pemimpin Teknologi</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t, idx) => (
            <div
              key={idx}
              className="glass-panel !bg-[#0b0e17]/85 !p-8 border border-white/10 hover:border-amber-500/40 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-1 mb-4 text-amber-400">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400" />
                  ))}
                </div>
                <Quote className="w-8 h-8 text-white/10 mb-2" />
                <p className="text-slate-300 text-xs sm:text-sm leading-relaxed italic mb-6">
                  "{t.quote}"
                </p>
              </div>

              <div className="pt-4 border-t border-white/10">
                <div className="font-display font-bold text-sm text-white">{t.author}</div>
                <div className="text-[11px] font-mono-code text-cyan-400">{t.role}</div>
                <div className="text-[11px] text-slate-400">{t.company}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* FAQ Accordion Section */}
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="badge-tag !py-1 !px-3 mb-3">
            <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
            <span>Klaritas & Kebijakan Transparan</span>
          </div>
          <h2 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight">
            Pertanyaan yang Sering Diajukan (FAQ)
          </h2>
          <p className="text-slate-300 text-sm mt-2">
            Segala hal seputar hak kepemilikan kode, termin pembayaran, dan garansi pasca rilis.
          </p>
        </div>

        <div className="space-y-4">
          {FAQS_DATA.map((faq, idx) => {
            const isOpen = openFAQ === idx;
            return (
              <div
                key={idx}
                className="glass-panel !bg-[#0c0f18]/90 border border-white/10 overflow-hidden transition-all duration-200"
              >
                <button
                  type="button"
                  onClick={() => setOpenFAQ(isOpen ? null : idx)}
                  className="w-full p-6 text-left flex items-center justify-between gap-4 cursor-pointer"
                >
                  <span className="font-display font-bold text-base sm:text-lg text-white">
                    {faq.question}
                  </span>
                  <div
                    className={`w-8 h-8 rounded-full bg-white/5 flex items-center justify-center shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 bg-amber-500 text-black' : 'text-slate-400'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 pt-1 text-slate-300 text-sm leading-relaxed border-t border-white/5">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
