import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight, Terminal, MessageCircle } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Layanan', href: '#services' },
    { name: 'Portofolio', href: '#portfolio' },
    { name: 'Alur Kerja', href: '#workflow' },
    { name: 'Tech Radar', href: '#tech-radar' },
    { name: 'Estimator Biaya', href: '#estimator' },
    { name: 'FAQ', href: '#faq' },
  ];

  const handleWhatsAppClick = () => {
    const message = encodeURIComponent(
      `Halo Tim ${COMPANY_INFO.name}, saya ingin berdiskusi mengenai kebutuhan pengembangan software untuk bisnis saya.`
    );
    window.open(`https://wa.me/${COMPANY_INFO.whatsappNumber}?text=${message}`, '_blank');
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 flex justify-center px-4 pt-4 sm:pt-6 transition-all duration-300">
      <nav
        className={`w-full max-w-7xl flex items-center justify-between px-5 sm:px-8 py-3.5 rounded-2xl transition-all duration-300 ${
          isScrolled
            ? 'bg-[#0a0d14]/85 backdrop-blur-xl border border-white/10 shadow-2xl shadow-black/80'
            : 'bg-[#0a0d14]/40 backdrop-blur-md border border-white/5'
        }`}
      >
        {/* Brand Logo */}
        <a href="#" className="flex items-center gap-3 group text-decoration-none">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#f59e0b] via-[#d97706] to-[#78350f] p-[1.5px] transition-transform duration-300 group-hover:scale-105">
            <div className="w-full h-full bg-[#080a0f] rounded-[10px] flex items-center justify-center">
              <span className="font-display font-black text-lg bg-gradient-to-r from-[#f59e0b] to-[#fbbf24] bg-clip-text text-transparent">
                K
              </span>
            </div>
          </div>
          <div className="flex flex-col">
            <span className="font-display font-bold text-lg tracking-wider text-white group-hover:text-[#f59e0b] transition-colors">
              KAFEINARTS
            </span>
            <span className="font-mono-code text-[10px] text-[#00f2fe] flex items-center gap-1.5 uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00f2fe] animate-pulse"></span>
              Digital Studio
            </span>
          </div>
        </a>

        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center gap-1 xl:gap-2">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-slate-300 hover:text-[#f59e0b] transition-colors duration-200"
            >
              {link.name}
            </a>
          ))}
        </div>

        {/* Actions & WhatsApp button */}
        <div className="hidden sm:flex items-center gap-3">
          <a
            href="#estimator"
            className="text-xs font-mono-code px-3.5 py-2 rounded-lg text-amber-300/90 hover:text-amber-200 border border-amber-500/20 hover:border-amber-500/50 bg-amber-500/5 transition-all flex items-center gap-1.5"
          >
            <Terminal className="w-3.5 h-3.5 text-amber-400" />
            <span>Kalkulator Scope</span>
          </a>

          <button
            onClick={handleWhatsAppClick}
            className="btn-gold !py-2 !px-4 !text-xs !rounded-xl"
          >
            <MessageCircle className="w-4 h-4 fill-black text-black" />
            <span>Konsultasi Proyek</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/5 transition-colors"
          aria-label="Toggle Navigation Menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-x-4 top-20 bg-[#0c0f17]/95 backdrop-blur-2xl border border-white/10 rounded-2xl p-6 shadow-2xl z-50 flex flex-col gap-4 animate-in fade-in duration-200">
          <div className="flex flex-col gap-2 pb-4 border-b border-white/10">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="py-2.5 px-3 text-sm font-semibold text-slate-200 hover:text-[#f59e0b] hover:bg-white/5 rounded-lg transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>
          <div className="flex flex-col gap-3">
            <a
              href="#estimator"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full text-center py-2.5 rounded-xl border border-amber-500/30 text-amber-300 font-mono-code text-xs bg-amber-500/10"
            >
              Kalkulator Scope & Biaya
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                handleWhatsAppClick();
              }}
              className="btn-gold w-full justify-center !py-2.5"
            >
              <MessageCircle className="w-4 h-4 fill-black text-black" />
              <span>Konsultasi via WhatsApp</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
