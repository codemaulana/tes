import React, { useState } from 'react';
import { ArrowUpRight, Sparkles, Filter } from 'lucide-react';
import { CASE_STUDIES } from '../data/content';
import { CaseStudy } from '../types';
import { CaseStudyModal } from './CaseStudyModal';

export const PortfolioShowcase: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'web' | 'mobile' | 'enterprise'>('all');
  const [selectedCaseStudy, setSelectedCaseStudy] = useState<CaseStudy | null>(null);

  const filteredProjects = CASE_STUDIES.filter((item) => {
    if (activeFilter === 'all') return true;
    return item.category === activeFilter;
  });

  return (
    <section id="portfolio" className="relative w-full max-w-7xl mx-auto px-4 py-24 sm:py-32">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
        <div>
          <div className="badge-tag !py-1 !px-3 mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Proven Engineering Records</span>
          </div>
          <h2 className="font-display font-black text-3xl sm:text-5xl text-white tracking-tight">
            Studi Kasus & <br />
            <span className="text-[#f59e0b]">Portofolio Terpilih</span>
          </h2>
        </div>
        <p className="max-w-md text-slate-300 text-sm leading-relaxed">
          Bukan sekadar screenshot antarmuka. Kami memaparkan arsitektur data nyata, mitigasi kendala teknis, dan pertumbuhan terukur klien kami.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 mb-10 pb-4 border-b border-white/10">
        <span className="text-xs font-mono-code text-slate-400 mr-2 flex items-center gap-1">
          <Filter className="w-3.5 h-3.5 text-amber-400" />
          Filter:
        </span>
        {[
          { id: 'all', label: 'Semua Proyek' },
          { id: 'web', label: 'Web Platform & SaaS' },
          { id: 'mobile', label: 'Mobile Apps' },
          { id: 'enterprise', label: 'Enterprise & ERP' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveFilter(tab.id as any)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeFilter === tab.id
                ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20 font-bold'
                : 'bg-white/5 text-slate-300 hover:bg-white/10 border border-white/5'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Project Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredProjects.map((project) => (
          <div
            key={project.id}
            onClick={() => setSelectedCaseStudy(project)}
            className="group glass-panel !bg-[#0b0e17]/85 rounded-3xl overflow-hidden border border-white/10 hover:border-amber-500/40 transition-all duration-300 cursor-pointer flex flex-col justify-between"
          >
            {/* Image Preview with Device Mockup aesthetic */}
            <div className="relative aspect-[16/10] w-full overflow-hidden bg-black/60">
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b0e17] via-transparent to-transparent opacity-80" />

              {/* Top Badge Overlay */}
              <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                <span className="badge-tag !bg-black/60 backdrop-blur-md text-[10px]">
                  {project.industry}
                </span>
                <div className="w-8 h-8 rounded-full bg-black/60 backdrop-blur-md border border-white/15 flex items-center justify-center text-slate-300 group-hover:bg-amber-500 group-hover:text-black transition-all">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Content Details */}
            <div className="p-6 flex-1 flex flex-col justify-between">
              <div>
                <div className="text-[11px] font-mono-code text-cyan-400 mb-1.5 uppercase tracking-wider">
                  Klien: {project.client}
                </div>
                <h3 className="font-display font-bold text-lg sm:text-xl text-white group-hover:text-amber-300 transition-colors mb-2 leading-snug">
                  {project.title}
                </h3>
                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed mb-4">
                  {project.summary}
                </p>
              </div>

              {/* Metrics Chips */}
              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-display font-black text-sm text-amber-400">
                    {project.impactMetrics[0].value}
                  </span>
                  <span className="text-[10px] font-mono-code text-slate-400">
                    {project.impactMetrics[0].label}
                  </span>
                </div>

                <span className="text-[11px] font-mono-code text-slate-400 group-hover:text-amber-400 flex items-center gap-1 transition-colors">
                  <span>Lihat Studi Kasus</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Case Study Modal */}
      <CaseStudyModal
        caseStudy={selectedCaseStudy}
        onClose={() => setSelectedCaseStudy(null)}
      />
    </section>
  );
};
