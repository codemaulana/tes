import React from 'react';
import { X, TrendingUp, Cpu, Layers, MessageCircle, ArrowRight } from 'lucide-react';
import { CaseStudy } from '../types';
import { COMPANY_INFO } from '../data/content';

interface CaseStudyModalProps {
  caseStudy: CaseStudy | null;
  onClose: () => void;
}

export const CaseStudyModal: React.FC<CaseStudyModalProps> = ({ caseStudy, onClose }) => {
  if (!caseStudy) return null;

  const handleConsultSimilar = () => {
    const text = encodeURIComponent(
      `Halo ${COMPANY_INFO.name}, saya membaca studi kasus "${caseStudy.title}" dan tertarik membangun solusi berarsitektur serupa untuk bisnis saya.`
    );
    window.open(`https://wa.me/${COMPANY_INFO.whatsappNumber}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto bg-[#0d1017] border border-white/15 rounded-3xl p-6 sm:p-10 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          aria-label="Tutup Modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Tags */}
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <span className="badge-tag text-xs">{caseStudy.industry}</span>
          <span className="badge-cyan text-xs uppercase">{caseStudy.category} Architecture</span>
        </div>

        <h2 className="font-display font-extrabold text-2xl sm:text-4xl text-white mb-2 leading-tight">
          {caseStudy.title}
        </h2>
        <div className="text-xs font-mono-code text-slate-400 mb-6">
          Klien: <span className="text-white font-semibold">{caseStudy.client}</span>
        </div>

        {/* Case Study Mockup Hero Image */}
        <div className="relative w-full aspect-video rounded-2xl overflow-hidden border border-white/10 mb-8 bg-black">
          <img
            src={caseStudy.image}
            alt={caseStudy.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Impact Metrics Banner */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-white/[0.02] border border-white/10 mb-8">
          {caseStudy.impactMetrics.map((metric, i) => (
            <div key={i} className="flex flex-col p-3 rounded-xl bg-white/[0.02]">
              <span className="text-xs font-mono-code text-slate-400">{metric.label}</span>
              <span className="font-display font-black text-2xl text-amber-400 my-0.5">
                {metric.value}
              </span>
              <span className="text-[11px] text-emerald-400 flex items-center gap-1 font-mono-code">
                <TrendingUp className="w-3 h-3" />
                {metric.trend}
              </span>
            </div>
          ))}
        </div>

        {/* Challenge & Solution Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="p-5 rounded-2xl bg-red-500/5 border border-red-500/10">
            <h3 className="text-xs font-mono-code uppercase tracking-wider text-red-400 mb-2 font-bold">
              The Architectural Challenge
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {caseStudy.challenge}
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-emerald-500/5 border border-emerald-500/10">
            <h3 className="text-xs font-mono-code uppercase tracking-wider text-emerald-400 mb-2 font-bold">
              Kafeinarts Engineering Solution
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {caseStudy.solution}
            </p>
          </div>
        </div>

        {/* Technical Architecture Bullet Points */}
        <div className="mb-8">
          <h3 className="text-sm font-display font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>Spesifikasi Arsitektur Sistem</span>
          </h3>
          <div className="space-y-2.5">
            {caseStudy.architecture.map((item, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl bg-white/[0.02] border border-white/5 text-xs text-slate-300 font-mono-code flex items-start gap-2.5"
              >
                <span className="text-cyan-400 font-bold shrink-0">#0{idx + 1}</span>
                <span>{item}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Tech Stack Chips */}
        <div className="mb-8">
          <div className="text-xs font-mono-code text-slate-400 mb-2.5 flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-amber-400" />
            <span>Teknologi yang Digunakan</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {caseStudy.techStack.map((tech) => (
              <span
                key={tech}
                className="px-3 py-1 text-xs font-mono-code rounded-lg bg-white/5 text-slate-200 border border-white/10"
              >
                {tech}
              </span>
            ))}
          </div>
        </div>

        {/* Action Button */}
        <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-6 border-t border-white/10">
          <button
            onClick={onClose}
            className="w-full sm:w-auto btn-secondary !py-2.5 !px-5 text-xs justify-center"
          >
            <span>Tutup Studi Kasus</span>
          </button>
          <button
            onClick={handleConsultSimilar}
            className="w-full sm:w-auto btn-gold !py-2.5 !px-5 text-xs justify-center"
          >
            <MessageCircle className="w-4 h-4 fill-black text-black" />
            <span>Konsultasikan Kebutuhan Serupa</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
