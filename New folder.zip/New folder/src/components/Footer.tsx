import React, { useState } from 'react';
import { Check } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setTimeout(() => setSubscribed(false), 4000);
      setEmail('');
    }
  };

  return (
    <footer className="relative w-full bg-[#050608] border-t border-white/10 pt-20 pb-12 overflow-hidden">
      {/* Background Ambient Glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[300px] bg-gradient-to-t from-amber-500/10 via-cyan-500/5 to-transparent blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4">
        {/* Top Newsletter & Bio Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-16 border-b border-white/10">
          <div className="lg:col-span-6">
            <h3 className="font-display font-black text-2xl sm:text-3xl text-white mb-2">
              Stay in the Engineering Loop.
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm max-w-md leading-relaxed mb-6">
              Dapatkan wawasan mingguan seputar arsitektur cloud, performa sistem web, dan studi kasus rekayasa software eksklusif dari tim Kafeinarts.
            </p>

            <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2.5 max-w-md">
              <input
                type="email"
                required
                placeholder="Masukkan email profesional Anda..."
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="glass-input flex-1 text-xs"
              />
              <button
                type="submit"
                className="btn-gold !py-2.5 !px-5 text-xs whitespace-nowrap justify-center"
              >
                {subscribed ? (
                  <span className="flex items-center gap-1.5 text-black">
                    <Check className="w-4 h-4" /> Berlangganan!
                  </span>
                ) : (
                  <span>Subscribe</span>
                )}
              </button>
            </form>
          </div>

          {/* Quick Links Column */}
          <div className="lg:col-span-6 grid grid-cols-2 sm:grid-cols-3 gap-8">
            <div>
              <div className="text-xs font-mono-code text-slate-400 uppercase tracking-widest mb-4">
                Navigasi
              </div>
              <ul className="space-y-2.5 text-xs">
                <li>
                  <a href="#services" className="text-slate-300 hover:text-amber-400 transition-colors">
                    Layanan IT
                  </a>
                </li>
                <li>
                  <a href="#portfolio" className="text-slate-300 hover:text-amber-400 transition-colors">
                    Studi Kasus
                  </a>
                </li>
                <li>
                  <a href="#workflow" className="text-slate-300 hover:text-amber-400 transition-colors">
                    Alur Kerja Sprint
                  </a>
                </li>
                <li>
                  <a href="#tech-radar" className="text-slate-300 hover:text-amber-400 transition-colors">
                    Tech Radar
                  </a>
                </li>
                <li>
                  <a href="#estimator" className="text-slate-300 hover:text-amber-400 transition-colors">
                    Estimator Scope
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <div className="text-xs font-mono-code text-slate-400 uppercase tracking-widest mb-4">
                Spesialisasi
              </div>
              <ul className="space-y-2.5 text-xs text-slate-400">
                <li>SaaS Engineering</li>
                <li>Mobile iOS & Android</li>
                <li>Enterprise ERP & CRM</li>
                <li>AI Integration & RAG</li>
                <li>Cloud DevOps & SLA</li>
              </ul>
            </div>

            <div>
              <div className="text-xs font-mono-code text-slate-400 uppercase tracking-widest mb-4">
                Terhubung
              </div>
              <ul className="space-y-2.5 text-xs">
                <li>
                  <a
                    href="https://github.com"
                    target="_blank"
                    rel="noreferrer"
                    className="text-slate-300 hover:text-amber-400 transition-colors flex items-center gap-1.5"
                  >
                    <span>GitHub</span>
                  </a>
                </li>
                <li>
                  <a
                    href="https://linkedin.com"
                    target="_blank"
                    rel="noreferrer"
                    className="text-slate-300 hover:text-amber-400 transition-colors flex items-center gap-1.5"
                  >
                    <span>LinkedIn</span>
                  </a>
                </li>
                <li>
                  <a
                    href="https://instagram.com"
                    target="_blank"
                    rel="noreferrer"
                    className="text-slate-300 hover:text-amber-400 transition-colors flex items-center gap-1.5"
                  >
                    <span>Instagram</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Oversized Brand Typography (Like in the video) */}
        <div className="py-12 sm:py-16 text-center select-none overflow-hidden">
          <div className="font-display font-black text-[13vw] leading-none tracking-tighter text-white/[0.04] hover:text-white/[0.08] transition-colors duration-500 uppercase">
            KAFEINARTS
          </div>
        </div>

        {/* Bottom Bar Legal & Copyright */}
        <div className="pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono-code text-slate-500">
          <div>
            &copy; {new Date().getFullYear()} {COMPANY_INFO.legalName}. All rights reserved.
          </div>
          <div className="flex items-center gap-6 text-[11px]">
            <span>100% Client Code Ownership Guarantee</span>
            <span>NDA Protected</span>
            <span>ISO 27001 Ready</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
