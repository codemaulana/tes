import React, { useState } from 'react';
import { Globe, Smartphone, Layers, Server, Cpu, Palette, ArrowRight, Sparkles } from 'lucide-react';
import { SERVICES_DATA } from '../data/content';
import { Service } from '../types';
import { ServiceModal } from './ServiceModal';

interface ServicesEngineProps {
  onSelectServiceForEstimator: (platform: string) => void;
}

export const ServicesEngine: React.FC<ServicesEngineProps> = ({ onSelectServiceForEstimator }) => {
  const [selectedService, setSelectedService] = useState<Service | null>(null);

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Globe':
        return <Globe className="w-5 h-5 text-amber-400" />;
      case 'Smartphone':
        return <Smartphone className="w-5 h-5 text-cyan-400" />;
      case 'Layers':
        return <Layers className="w-5 h-5 text-amber-300" />;
      case 'Server':
        return <Server className="w-5 h-5 text-cyan-300" />;
      case 'Cpu':
        return <Cpu className="w-5 h-5 text-emerald-400" />;
      case 'Palette':
        return <Palette className="w-5 h-5 text-purple-400" />;
      default:
        return <Globe className="w-5 h-5 text-amber-400" />;
    }
  };

  const mapServiceToPlatform = (serviceId: string) => {
    if (serviceId.includes('web')) return 'web';
    if (serviceId.includes('mobile')) return 'mobile';
    if (serviceId.includes('enterprise')) return 'enterprise';
    if (serviceId.includes('ai') || serviceId.includes('cloud')) return 'ai';
    return 'web';
  };

  const handleEstimatorJump = (serviceId: string) => {
    const platform = mapServiceToPlatform(serviceId);
    onSelectServiceForEstimator(platform);
    const element = document.getElementById('estimator');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="services" className="relative w-full max-w-7xl mx-auto px-4 py-24 sm:py-32">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
        <div>
          <div className="badge-tag !py-1 !px-3 mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Core IT Capabilities</span>
          </div>
          <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white tracking-tight">
            Layanan Rekayasa <br />
            <span className="text-[#f59e0b]">Software & Arsitektur</span>
          </h2>
        </div>
        <p className="max-w-md text-slate-300 text-sm leading-relaxed">
          Setiap solusi dikembangkan dari nol dengan standar clean code dan arsitektur modular yang siap di-scale hingga jutaan transaksi per hari.
        </p>
      </div>

      {/* 6 Services Grid (Awwwards Style with Cursor-Tilted Glow) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {SERVICES_DATA.map((service) => (
          <div
            key={service.id}
            className="group relative glass-panel !bg-[#0b0e17]/80 !p-7 flex flex-col justify-between overflow-hidden cursor-pointer hover:border-amber-500/40 transition-all duration-300"
            onClick={() => setSelectedService(service)}
          >
            {/* Top Number & Tag */}
            <div className="flex items-center justify-between mb-6">
              <span className="font-mono-code text-xs font-semibold px-2.5 py-1 rounded bg-white/5 text-slate-400 border border-white/10 group-hover:text-amber-400 group-hover:border-amber-500/30 transition-colors">
                {service.number}
              </span>
              <span className="badge-cyan text-[11px]">{service.tag}</span>
            </div>

            {/* Icon & Title */}
            <div>
              <div className="w-12 h-12 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-amber-500/10 group-hover:border-amber-500/30 transition-all duration-300">
                {getIcon(service.iconName)}
              </div>

              <h3 className="font-display font-bold text-xl text-white group-hover:text-amber-300 transition-colors mb-2.5">
                {service.title}
              </h3>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                {service.shortDesc}
              </p>
            </div>

            {/* Bottom Stack & CTA */}
            <div className="pt-5 border-t border-white/10 flex items-center justify-between">
              <div className="flex flex-wrap gap-1 max-w-[70%]">
                {service.techStack.slice(0, 3).map((tech) => (
                  <span
                    key={tech}
                    className="text-[10px] font-mono-code text-slate-400 bg-white/5 px-2 py-0.5 rounded border border-white/5"
                  >
                    {tech}
                  </span>
                ))}
                {service.techStack.length > 3 && (
                  <span className="text-[10px] font-mono-code text-slate-400 px-1 py-0.5">
                    +{service.techStack.length - 3}
                  </span>
                )}
              </div>

              <button
                type="button"
                className="w-8 h-8 rounded-full bg-white/5 group-hover:bg-amber-500 text-slate-400 group-hover:text-black flex items-center justify-center transition-all duration-200"
                aria-label={`Buka detail ${service.title}`}
              >
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>

            {/* Corner Decorative Glow */}
            <div className="absolute -top-12 -right-12 w-28 h-28 bg-amber-500/5 group-hover:bg-amber-500/15 rounded-full blur-xl pointer-events-none transition-all duration-300" />
          </div>
        ))}
      </div>

      {/* Interactive Deep-Dive Modal */}
      <ServiceModal
        service={selectedService}
        onClose={() => setSelectedService(null)}
        onSelectForEstimator={(serviceId) => handleEstimatorJump(serviceId)}
      />
    </section>
  );
};
