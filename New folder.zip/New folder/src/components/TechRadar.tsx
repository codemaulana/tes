import React, { useState } from 'react';
import { Cpu, Zap, Check } from 'lucide-react';
import { TECH_RADAR } from '../data/content';

export const TechRadar: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'Frontend', 'Backend', 'Database', 'Mobile', 'DevOps'];

  const filteredItems = activeCategory === 'All'
    ? TECH_RADAR
    : TECH_RADAR.filter((item) => item.category === activeCategory);

  const benchmarks = [
    { metric: 'Rata-rata API Response Time', conventional: '350 - 650 ms', kafeinarts: '< 65 ms', win: true },
    { metric: 'Automated Test Coverage', conventional: '25% - 40%', kafeinarts: '> 90%', win: true },
    { metric: 'Docker Container Bootup', conventional: '45 - 90 detik', kafeinarts: '< 8 detik', win: true },
    { metric: 'Lighthouse Performance Score', conventional: '65 - 80 / 100', kafeinarts: '95 - 100 / 100', win: true },
  ];

  return (
    <section id="tech-radar" className="relative w-full max-w-7xl mx-auto px-4 py-24 sm:py-32">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
        <div>
          <div className="badge-tag !py-1 !px-3 mb-3">
            <Cpu className="w-3.5 h-3.5 text-amber-400" />
            <span>Modern Production Tech Stack</span>
          </div>
          <h2 className="font-display font-black text-3xl sm:text-5xl text-white tracking-tight">
            Engineering Radar & <br />
            <span className="text-[#f59e0b]">Benchmark Performa</span>
          </h2>
        </div>
        <p className="max-w-md text-slate-300 text-sm leading-relaxed">
          Kami menolak stack usang. Seluruh aplikasi dibangun dengan ekosistem bahasa pemrograman dan framework modern yang teruji di industri global.
        </p>
      </div>

      {/* Categories Filter */}
      <div className="flex flex-wrap items-center gap-2 mb-8">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-mono-code transition-all ${
              activeCategory === cat
                ? 'bg-amber-500 text-black font-bold shadow-md shadow-amber-500/20'
                : 'bg-white/5 text-slate-300 hover:bg-white/10 border border-white/5'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Tech Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5 mb-16">
        {filteredItems.map((tech, idx) => (
          <div
            key={idx}
            className="p-4 rounded-2xl bg-[#0b0e17]/80 border border-white/10 hover:border-amber-500/40 transition-all flex flex-col justify-between group"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] font-mono-code uppercase tracking-wider text-cyan-400">
                {tech.category}
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </div>

            <h4 className="font-display font-bold text-white text-sm group-hover:text-amber-400 transition-colors">
              {tech.name}
            </h4>

            <div className="text-[11px] font-mono-code text-slate-400 mt-2 pt-2 border-t border-white/5">
              {tech.status}
            </div>
          </div>
        ))}
      </div>

      {/* Benchmark Matrix Box */}
      <div className="glass-panel !bg-[#0c0f18]/90 !p-8 border border-white/10 rounded-3xl overflow-hidden relative">
        <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/10">
          <Zap className="w-5 h-5 text-amber-400" />
          <h3 className="font-display font-bold text-lg sm:text-xl text-white">
            Standar Rekayasa Kafeinarts vs. Software House Konvensional
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono-code">
            <thead>
              <tr className="border-b border-white/10 text-slate-400">
                <th className="py-3 px-4 font-semibold">Parameter Arsitektur</th>
                <th className="py-3 px-4 font-semibold text-slate-400">Vendor Konvensional</th>
                <th className="py-3 px-4 font-semibold text-amber-400">CV. Kafeinarts</th>
                <th className="py-3 px-4 font-semibold text-right">Verifikasi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {benchmarks.map((b, i) => (
                <tr key={i} className="hover:bg-white/[0.02] transition-colors">
                  <td className="py-3.5 px-4 font-sans font-medium text-white">{b.metric}</td>
                  <td className="py-3.5 px-4 text-slate-400">{b.conventional}</td>
                  <td className="py-3.5 px-4 text-amber-400 font-bold">{b.kafeinarts}</td>
                  <td className="py-3.5 px-4 text-right">
                    <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      <Check className="w-3 h-3" />
                      Benchmarked
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};
