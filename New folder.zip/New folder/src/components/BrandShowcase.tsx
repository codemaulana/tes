import React from 'react';
import { Terminal, Shield, Zap, Sparkles } from 'lucide-react';

export const BrandShowcase: React.FC = () => {
  return (
    <section className="relative w-full max-w-7xl mx-auto px-4 py-24 sm:py-32 overflow-hidden">
      {/* Editorial Headline Statement */}
      <div className="flex flex-col items-center text-center max-w-3xl mx-auto mb-14">
        <div className="badge-tag !py-1 !px-3 mb-4">
          <Terminal className="w-3.5 h-3.5 text-amber-400" />
          <span>The Kafeinarts Engineering Standard</span>
        </div>
        <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white tracking-tight leading-tight">
          Bukan Sekadar Menulis Kode. <br />
          Kami Meracik <span className="text-[#f59e0b]">Keunggulan Arsitektural</span>.
        </h2>
        <p className="text-slate-300 text-sm sm:text-base mt-4 leading-relaxed">
          Banyak software house membuang waktu dengan boilerplate generik dan AI slop yang sulit di-maintain. Di Kafeinarts, setiap modul kode dibangun dengan prinsip modularitas tinggi, dokumentasi ketat, dan keamanan standar enterprise.
        </p>
      </div>

      {/* Cinematic Panoramic Showcase with Glass Overlay */}
      <div className="relative rounded-3xl overflow-hidden border border-white/10 shadow-2xl group">
        <div className="aspect-[21/9] sm:aspect-[24/10] w-full relative">
          <img
            src="/images/skyline.jpg"
            alt="Futuristic Software Engineering Metropolis"
            className="w-full h-full object-cover transform transition-transform duration-1000 group-hover:scale-105"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#07080c] via-[#07080c]/40 to-transparent" />
          <div className="absolute inset-0 bg-radial-gradient from-transparent to-[#07080c]/60" />
        </div>

        {/* Floating Feature Grid inside Panorama */}
        <div className="absolute bottom-6 sm:bottom-10 inset-x-6 sm:inset-x-12 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="glass-panel !bg-[#0b0e17]/85 !p-5 border border-white/10 hover:border-amber-500/40 transition-all">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 mb-3">
              <Zap className="w-5 h-5" />
            </div>
            <h3 className="font-display font-bold text-white text-base">Sub-100ms Performance</h3>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Arsitektur edge-caching & database indexing ketat memastikan respon sistem secepat kedipan mata.
            </p>
          </div>

          <div className="glass-panel !bg-[#0b0e17]/85 !p-5 border border-white/10 hover:border-cyan-500/40 transition-all">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 mb-3">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="font-display font-bold text-white text-base">100% Code Ownership</h3>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Seluruh hak cipta, repositori Git, dan rahasia dagang diserahkan utuh kepada klien tanpa keterikatan lisensi tersembunyi.
            </p>
          </div>

          <div className="glass-panel !bg-[#0b0e17]/85 !p-5 border border-white/10 hover:border-emerald-500/40 transition-all">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mb-3">
              <Sparkles className="w-5 h-5" />
            </div>
            <h3 className="font-display font-bold text-white text-base">Zero Technical Debt</h3>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Disertai automated unit testing dan documentation handbook terstruktur agar tim internal Anda mudah melanjutkan pengembangan.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
