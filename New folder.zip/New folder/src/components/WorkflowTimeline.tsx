import React from 'react';
import { WORKFLOW_STAGES } from '../data/content';
import { GitPullRequest, CheckCircle2, ShieldCheck, Clock } from 'lucide-react';

export const WorkflowTimeline: React.FC = () => {
  return (
    <section id="workflow" className="relative w-full max-w-7xl mx-auto px-4 py-24 sm:py-32">
      {/* Background Subtle Gradient */}
      <div className="absolute top-1/3 left-10 w-96 h-96 bg-cyan-500/5 rounded-full blur-[140px] pointer-events-none -z-10" />

      {/* Split Pinned Layout (Like in the video) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Left Column (Sticky Pinned on Desktop) */}
        <div className="lg:col-span-5 lg:sticky lg:top-32">
          <div className="badge-tag !py-1 !px-3 mb-4">
            <GitPullRequest className="w-3.5 h-3.5 text-amber-400" />
            <span>Structured Sprint Engine</span>
          </div>

          <h2 className="font-display font-black text-3xl sm:text-5xl text-white tracking-tight leading-tight">
            Metodologi Rekayasa <br />
            <span className="text-[#f59e0b]">Tanpa Proyek Mangkrak</span>.
          </h2>

          <p className="text-slate-300 text-sm sm:text-base mt-4 leading-relaxed">
            Kegagalan proyek IT sering terjadi karena komunikasi buram dan estimasi asal-asalan. Di CV. Kafeinarts, kami memecah proses menjadi 5 fase transparan dengan staging demo 2 mingguan dan kontrak SLA tertulis.
          </p>

          {/* Guarantee Pill */}
          <div className="mt-8 p-4 rounded-2xl bg-white/[0.02] border border-white/10 flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white">Full IP & Git Source Code Handoff</div>
              <div className="text-[11px] text-slate-400 font-mono-code">100% Hak Milik Klien Tanpa Royalti</div>
            </div>
          </div>
        </div>

        {/* Right Column: 5 Sequential Stages */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          {WORKFLOW_STAGES.map((stage) => (
            <div
              key={stage.step}
              className="group glass-panel !bg-[#0b0e17]/85 !p-8 border border-white/10 hover:border-amber-500/40 transition-all duration-300 relative overflow-hidden"
            >
              {/* Top Accent Line */}
              <div
                className="absolute top-0 left-0 right-0 h-[2px] opacity-40 group-hover:opacity-100 transition-opacity"
                style={{ backgroundColor: stage.accent }}
              />

              {/* Step Number & Duration */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span
                    className="font-mono-code text-sm font-extrabold px-3 py-1 rounded-lg border"
                    style={{
                      backgroundColor: `${stage.accent}15`,
                      color: stage.accent,
                      borderColor: `${stage.accent}40`
                    }}
                  >
                    PHASE {stage.step}
                  </span>
                  <span className="text-xs font-mono-code text-slate-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {stage.duration}
                  </span>
                </div>
              </div>

              {/* Title & Subtitle */}
              <h3 className="font-display font-bold text-xl sm:text-2xl text-white group-hover:text-amber-300 transition-colors mb-1">
                {stage.title}
              </h3>
              <div className="text-xs font-mono-code text-cyan-400 mb-3">
                {stage.subtitle}
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                {stage.description}
              </p>

              {/* Outputs / Deliverables Checklist */}
              <div className="pt-4 border-t border-white/10 space-y-2">
                <div className="text-[11px] font-mono-code uppercase tracking-wider text-slate-400 mb-2">
                  Output Resmi Fase Ini:
                </div>
                {stage.outputs.map((out, oIdx) => (
                  <div key={oIdx} className="flex items-start gap-2.5 text-xs text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{out}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
